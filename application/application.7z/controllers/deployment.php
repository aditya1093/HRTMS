<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Deployment extends CI_Controller {

	function __construct() {
		parent::__construct();
	}

	function index() {

		if($this->session->userdata('is_logged_in')) {

			$this->load->model('applicant_model');
			$query = $this->applicant_model->list_request();
			
			$data['records2'] = $query;
			
			$this->load->view('trainee/deployment_view',$data);
		}
		else {

    		$this->load->view('login_view');
		}	

	}

	function list_deployment(){
		$id = $this->input->post('id');

		//$query = $this->db->query('SELECT hris.first_name, hris.last_name, hris.middle_name FROM `batch_no` inner join hris on hris.batch_control_no = batch_no.batch_control_no where request_id = '.$id);
        //return $query->result();

		echo json_encode($id);





	}
	
}

/* End of file deployment.php */
/* Location: ./application/controllers/deployment.php */