<?php

class Deployment_model extends CI_Model{
    
    function __construct() {
        parent::__construct();
        
    }

    function list_trainee($id){

     $this->db->select('hris.trainee_id ,hris.first_name, hris.last_name, hris.middle_name');
     
    }
    
    

}